// colors.ts placeholder

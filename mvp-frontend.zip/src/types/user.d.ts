// user.d.ts placeholder
